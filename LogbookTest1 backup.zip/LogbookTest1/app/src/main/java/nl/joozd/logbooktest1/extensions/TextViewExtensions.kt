package nl.joozd.logbooktest1.extensions

import android.graphics.Typeface
import android.widget.TextView

fun TextView.showAsActive(){
    this.alpha=1.0F
    this.setTypeface(null, Typeface.BOLD)
}

fun TextView.showAsInactive(){
    this.alpha=0.5F
    this.setTypeface(null, Typeface.NORMAL)
}