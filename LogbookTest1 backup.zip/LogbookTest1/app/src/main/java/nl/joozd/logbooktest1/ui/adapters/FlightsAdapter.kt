package nl.joozd.logbooktest1.ui.adapters


import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.flight_item_new.*

import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.Flight
import android.widget.TextView
import nl.joozd.logbooktest1.data.db.AirportDb
import nl.joozd.logbooktest1.data.utils.flightAirportsToIata
import nl.joozd.logbooktest1.extensions.*
import nl.joozd.logbooktest1.utils.noColon
import nl.joozd.logbooktest1.utils.toMonthYear




private var normalColor: Int = 0
private var plannedColor: Int = 0
private val airportDb = AirportDb()


class FlightsAdapter(private var enteredFlights: List<Flight>, private val itemClick: (Flight) -> Unit) : RecyclerView.Adapter<FlightsAdapter.ViewHolder>() {

    private lateinit var mRecyclerView: RecyclerView


    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        super.onAttachedToRecyclerView(recyclerView)

        mRecyclerView = recyclerView
    }

    var icaoIataPairs=airportDb.makeIcaoIataPairs()
    private var allFlights = flightAirportsToIata(enteredFlights, icaoIataPairs)
    private var savedFlights=allFlights
    var flights: List<Flight>
        set(newFlights){
            allFlights = flightAirportsToIata(newFlights.filter {it.DELETEFLAG == 0}, icaoIataPairs)
            this.notifyDataSetChanged()
            val firstNotPlanned=allFlights.indexOfFirst { it.isPlanned == 0 }
            mRecyclerView.scrollToPosition(if (firstNotPlanned > 3) firstNotPlanned - 3 else 0)
        }
    get() = allFlights



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // val view = LayoutInflater.from(parent.ctx).inflate(R.layout.another_item_flight, parent, false)
        val view = LayoutInflater.from(parent.ctx).inflate(R.layout.flight_item_new, parent, false)
        normalColor = parent.ctx.getColorFromAttr(android.R.attr.textColorSecondary)
        plannedColor = parent.ctx.getColorFromAttr(android.R.attr.textColorHighlight)
        return ViewHolder(view, itemClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
         holder.bindFlight(allFlights[position])
    }

    override fun getItemCount(): Int = allFlights.size


    class ViewHolder(override val containerView: View, private val itemClick: (Flight) -> Unit) : RecyclerView.ViewHolder(containerView),
        LayoutContainer {
        fun bindFlight(flight: Flight) {
            with(flight) {
                for (c in 0 until flightLayout.childCount) {
                    val v: View = flightLayout.getChildAt(c)
                    if (v is TextView) {
                        v.setTextColor(if (planned) plannedColor else normalColor)
                    }
                }
                dateDayText.text = tOut.dayOfMonth.toString()
                dateMonthYearText.text = tOut.toMonthYear().toUpperCase()
                namesText.text = allNames
                if (sim) {
                    flightNumberText.visibility = View.INVISIBLE
                    registrationText.visibility = View.INVISIBLE
                    arrow1.visibility = View.INVISIBLE
                    arrow2.visibility = View.INVISIBLE
                    timeOutText.visibility = View.INVISIBLE
                    timeInText.visibility = View.INVISIBLE
                    destText.visibility = View.INVISIBLE
                    takeoffLandingText.visibility = View.INVISIBLE

                    totalTimeText.text = simTimeString
                    origText.text = origText.ctx.getText(R.string.simluator).toString().toUpperCase()
                } else {
                    flightNumberText.visibility = View.VISIBLE
                    registrationText.visibility = View.VISIBLE
                    arrow1.visibility = View.VISIBLE
                    arrow2.visibility = View.VISIBLE
                    timeOutText.visibility = View.VISIBLE
                    timeInText.visibility = View.VISIBLE
                    destText.visibility = View.VISIBLE
                    takeoffLandingText.visibility = View.VISIBLE

                    flightNumberText.text = flightNumber
                    origText.text = orig
                    destText.text = dest
                    timeOutText.text = tOut.noColon()
                    totalTimeText.text = totalTime
                    timeInText.text = tIn.noColon()
                    registrationText.text = registration
                    aircraftTypeText.text = aircraft
                    remarksText.text = remarks
                    takeoffLandingText.text = takeoffLanding
                }
                /*
                if (sim) isSimText.setLayoutToOn() else isSimText.setLayoutToOff()
                if (dual) isDualText.setLayoutToOn() else isDualText.setLayoutToOff()
                if (instructor) isInstructorText.setLayoutToOn() else isInstructorText.setLayoutToOff()
                if (picus) isPicusText.setLayoutToOn() else isPicusText.setLayoutToOff()
                if (pic) isPicText.setLayoutToOn() else isPicText.setLayoutToOff()
                if (pf) isPFText.setLayoutToOn() else isPFText.setLayoutToOff()
                */
                isSimText.visibility = if (sim) View.VISIBLE else View.GONE
                isDualText.visibility = if (dual) View.VISIBLE else View.GONE
                isInstructorText.visibility = if (instructor) View.VISIBLE else View.GONE
                isPicusText.visibility = if (picus) View.VISIBLE else View.GONE
                isPicText.visibility = if (pic) View.VISIBLE else View.GONE
                isPFText.visibility = if (pf) View.VISIBLE else View.GONE
                remarksText.visibility = if (remarks.isEmpty()) View.GONE else View.VISIBLE
                itemView.setOnClickListener { itemClick(this) }
            }

        }
    }

    fun restoreFlights(){
        allFlights=savedFlights
        this.notifyDataSetChanged()
    }
    fun saveFlights(){
        savedFlights=allFlights
    }
    fun insertFlight(flight: Flight) {
        if (allFlights.firstOrNull { it.flightID == flight.flightID } == null) { // its a new flight!
            allFlights += flightAirportsToIata(listOf(flight), icaoIataPairs)
        } else {// its a known flight!
            allFlights = allFlights.map { if (flight.flightID == it.flightID) flightAirportsToIata(listOf(flight), icaoIataPairs).first() else it}
        }
        this.notifyDataSetChanged()
    }

}