package nl.joozd.logbooktest1.data.enumclasses

enum class DayNight{ DAY, NIGHT }