package nl.joozd.logbooktest1.customs

import android.content.Context
import android.support.v7.widget.RecyclerView

class MyRecyclerView(context: Context): RecyclerView(context){
    override fun computeVerticalScrollExtent(): Int {
        return super.computeVerticalScrollExtent()
    }
}