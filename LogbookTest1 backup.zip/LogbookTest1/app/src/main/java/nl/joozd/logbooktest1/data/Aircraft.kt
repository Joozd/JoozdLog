package nl.joozd.logbooktest1.data

data class Aircraft(val id: Int, val registration: String, val manufacturer: String, val model: String, val engine_type: String, val mtow: Int, val se: Int, val me: Int, val multipilot: Int, val isIfr: Int)