
/*
package nl.joozd.logbooktest1.ui.fragments


import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.Flight
import nl.joozd.logbooktest1.data.db.AircraftDb
import nl.joozd.logbooktest1.data.db.AirportDb
import nl.joozd.logbooktest1.data.db.FlightDb
import nl.joozd.logbooktest1.data.utils.NamesWorker
import nl.joozd.logbooktest1.data.utils.makeEmptyFlight
import nl.joozd.logbooktest1.data.utils.saveAllDataToFlight
import nl.joozd.logbooktest1.extensions.ctx
import nl.joozd.logbooktest1.extensions.getColorFromAttr
import nl.joozd.logbooktest1.ui.dialogs.DatePickerFragment
import nl.joozd.logbooktest1.utils.*
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime

class EditFlight : Fragment() {
    private val myDB  = FlightDb()
    private val airportDb= AirportDb()
    private val aircraftDb = AircraftDb()

    var flightToEdit: Flight = makeEmptyFlight(myDB.highestId+1)
    var newFlight: Boolean = false
    var allNames: List<String> = emptyList()
    var saveChanges=true
    private lateinit var namesWorker: NamesWorker


    companion object {
        fun newInstance(): EditFlight {
            return EditFlight()
        }
    }
/*
 *  Implement listeners. Use like you would use an onClickListener.
 */
    class OnFileSavedListener (private val f: (flightToSave: Flight, oldFlight: Flight) ->Unit){ // oldFlight =  flight before changes, to undo if needed
        fun fileSaved(flightToSave: Flight, oldFlight: Flight){
            f(flightToSave, oldFlight)
        }
    }

    class OnFlightCancelledListener (private val f: (flight: Flight) -> Unit){ // flight = flight with changes, to undo if needed
        fun editCancelled(flight: Flight){
            f(flight)
        }
    }

    class OnViewDestroyedListener (private val f: () -> Unit) {
        fun viewDestroyed(){
            f()
        }
    }


    var onFlightCancelledListener: OnFlightCancelledListener? = null
    var onFileSavedListener: OnFileSavedListener? = null
    var onViewDestroyedListener: OnViewDestroyedListener? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        namesWorker=NamesWorker(allNames)
    }


    @SuppressLint("SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.flight_edit_old, container, false)



        val flightInfoText: TextView = view.findViewById(R.id.flightInfoText)
        val flightFlightID: TextView = view.findViewById(R.id.flightFlightID)
        val flighttOutText: TextView = view.findViewById(R.id.flighttOutText)
        val flightDateField: EditText = view.findViewById(R.id.flightDateField)
        val flightFlightNumberField: EditText = view.findViewById(R.id.flightFlightNumberField)
        val flightAircraftField: EditText = view.findViewById(R.id.flightAircraftField)
        val flightOrigField: EditText = view.findViewById(R.id.flightOrigField)
        val flightDestField: EditText = view.findViewById(R.id.flightDestField)
        val flighttOutStringField: EditText = view.findViewById(R.id.flighttOutStringField)
        val flighttInStringField: EditText = view.findViewById(R.id.flighttInStringField)
        val flightTakeoffLandingField: EditText = view.findViewById(R.id.flightTakeoffLandingField)
        val flightNameField: EditText = view.findViewById(R.id.flightNameField)
        val flightName2Field: EditText = view.findViewById(R.id.flightName2Field)
        val flightRemarksField: EditText = view.findViewById(R.id.flightRemarksField)
        val flightSimulatorCheckbox: CheckBox = view.findViewById(R.id.flightSimulatorCheckbox)
        val flightPicCheckbox: CheckBox = view.findViewById(R.id.flightPicCheckbox)
        val flightPicusCheckbox: CheckBox = view.findViewById(R.id.flightPicusCheckbox)
        val flightPilotFlyingCheckbox: CheckBox = view.findViewById(R.id.flightPilotFlyingCheckbox)
        val flightDualCheckbox: CheckBox = view.findViewById(R.id.flightDualCheckbox)
        val flightInstructorCheckbox: CheckBox = view.findViewById(R.id.flightInstructorCheckbox)
        val flightCancelButton: TextView = view.findViewById(R.id.flightCancelButton)
        val flightSavebutton: TextView = view.findViewById(R.id.flightSaveButton)
        val flightInfoDataLayout: ConstraintLayout = view.findViewById(R.id.flightInfoDataLayout)
        val flightInfoLayout: ConstraintLayout = view.findViewById(R.id.flightInfoLayout)
        val flightDateSelector: ImageView = view.findViewById(R.id.flightDateSelector)
        val flightAcRegSelector: ImageView = view.findViewById(R.id.flightAcRegSelector)
        val flightTakeoffLandingSelector: ImageView = view.findViewById(R.id.flightTakeoffLandingSelector)
        val flightNumberText: TextView = view.findViewById(R.id.flightNumberText)
        val totalTimeText: TextView = view.findViewById(R.id.totalTimeText)
        val origText: TextView = view.findViewById(R.id.origText)
        val destText: TextView = view.findViewById(R.id.destText)
        val tInText: TextView = view.findViewById(R.id.tInText)
        val takeoffLandingText: TextView = view.findViewById(R.id.takeoffLandingText)
        val hiddenLandingHelper: TextView = view.findViewById(R.id.hiddenLandingHelper)
        val hiddenNightTime: TextView = view.findViewById(R.id.hiddenNightTime)
        val hiddenIfrTime: TextView = view.findViewById(R.id.hiddenIfrTime)
        val autoFillCheckBox: CheckBox = view.findViewById(R.id.autoFillCheckBox)

        (flightInfoText.background as GradientDrawable).colorFilter = PorterDuffColorFilter(activity!!.getColorFromAttr(android.R.attr.colorPrimary), PorterDuff.Mode.SRC_IN)


        val flight=flightToEdit

        flightInfoText.text= if (newFlight) "Add Flight" else "Edit Flight"
        flightFlightID.text=flight.flightID.toString()
        if (!newFlight) flightDateField.setText(flight.date) else flightDateField.setText(LocalDate.now().toDateString())
        flightFlightNumberField.setText(flight.flightNumber)
        flightAircraftField.setText(if (!flight.sim) ("${flight.registration}(${flight.aircraft})") else ("${flight.aircraft}"))
        flightOrigField.setText(flight.orig)
        flightDestField.setText(flight.dest)
        if (!newFlight) flighttOutStringField.setText(flight.timeOut) else flighttOutStringField.setText("12:00")
        if (!newFlight) flighttInStringField.setText(flight.timeIn) else flighttInStringField.setText("13:00")
        if (flight.sim){
            makeItSim(flightNumberText, flightFlightNumberField, origText, destText, flightOrigField, flightDestField,
                flighttOutText, tInText, flighttInStringField, takeoffLandingText, flightTakeoffLandingField,
                flightPicCheckbox, flightPilotFlyingCheckbox, flightPicusCheckbox, flightDualCheckbox)
        }
        flightTakeoffLandingField.setText(flight.takeoffLanding)
        flightNameField.setText(flight.name)
        flightName2Field.setText(flight.name2)
        if (!newFlight) flightName2Field.hint=""
        flightRemarksField.setText(flight.remarks)
        if (!newFlight) flightRemarksField.hint = ""
        flightSimulatorCheckbox.isChecked=flight.sim
        flightPicCheckbox.isChecked=flight.pic
        flightPicusCheckbox.isChecked=flight.picus
        flightPilotFlyingCheckbox.isChecked=flight.pf
        updateTotalTime(totalTimeText, flighttOutStringField, flighttInStringField)
        hiddenIfrTime.text=flight.ifrTime.toString()
        hiddenNightTime.text=flight.ifrTime.toString()
        autoFillCheckBox.isChecked=flight.autoFill > 0


        // set landings to whatever is in the flight
        hiddenLandingHelper.text = (100000000 * flight.takeOffDay + 1000000 * flight.takeOffNight + 10000 * flight.landingDay + 100 * flight.landingNight + flight.autoLand).toString()
        // TODO check if all is set as autoFill would set it, then set autoFill accordingly

        flightPilotFlyingCheckbox.setOnCheckedChangeListener { _, _ ->
            autoValues(view)
        }
        autoFillCheckBox.setOnCheckedChangeListener { _, _ ->
            autoValues(view)
        }
        flightCancelButton.setOnClickListener { saveChanges = false; fragmentManager?.popBackStack() }
        flightInfoLayout.setOnClickListener { saveChanges = false; fragmentManager?.popBackStack() }
        flightSavebutton.setOnClickListener { saveChanges = true; fragmentManager?.popBackStack() }

        flightDateField.setOnClickListener {
            val datePickerFragment= DatePickerFragment()
            datePickerFragment.viewToUpdate=flightDateField
            datePickerFragment.show(activity?.supportFragmentManager, "datePicker")
        }
        flightDateSelector.setOnClickListener {
            activity?.currentFocus?.clearFocus()
            val datePickerFragment= DatePickerFragment()
            datePickerFragment.viewToUpdate=flightDateField
            datePickerFragment.show(activity?.supportFragmentManager, "datePicker")
        }
        flightFlightNumberField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            with(v as EditText) {
                var flightnumber = text.toString()
                var flightnumberDigits = ""
                while (flightnumber.last().isDigit()) {
                    flightnumberDigits = flightnumber.last() + flightnumberDigits
                    flightnumber = flightnumber.dropLast(1)
                }
                if (hasFocus) {
                    hint = text
                    this.setText(flightnumber)
                } else {
                    if (text.toString() == flightnumber) setText(hint)
                }
            }
        }

        flightAcRegSelector.setOnClickListener {
            activity?.currentFocus?.clearFocus()
            val aircraftPicker= AircraftPicker()
            aircraftPicker.flightSelectedListener = AircraftPicker.FlightSelectedListener { ac -> flightAircraftField.setText("${ac.registration}(${ac.model})") }
            // viewToUpdate?.setText("${pickedAircraft?.registration ?: ""}(${pickedAircraft?.model ?: ""})")
            aircraftPicker.viewToUpdate = flightAircraftField
            fragmentManager?.beginTransaction()
            ?.add(R.id.mainActivityLayout, aircraftPicker)
            ?.addToBackStack(null)
            ?.commit()
        }
        flightTakeoffLandingSelector.setOnClickListener {
            activity?.currentFocus?.clearFocus()
            val landingsPicker = LandingsPicker()
            landingsPicker.currentLandingData=hiddenLandingHelper.text.toString().toLong()
            landingsPicker.onSaveListener=LandingsPicker.OnSaveListener {
                landingData -> hiddenLandingHelper.text=landingData.toString()
                autoFillCheckBox.isChecked = false
                val landingData = hiddenLandingHelper.text.toString().toLong() // DTDLNTNLAL // 1.00.00.00.00.00 / 2/4/6/8/10 zeros
                val takeoffDay: Int = ((landingData%10000000000)/100000000).toInt()
                val takeoffNight: Int = ((landingData%100000000)/1000000).toInt()
                val landingDay: Int = ((landingData%1000000)/10000).toInt()
                val landingNight: Int = ((landingData%10000)/100).toInt()
                flightTakeoffLandingField.setText("${takeoffDay+takeoffNight}/${landingDay+landingNight}")
            }
            fragmentManager?.beginTransaction()?.add(R.id.mainActivityLayout, landingsPicker)?.addToBackStack(null)?.commit()
        }



        flighttOutStringField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    this.hint = this.text
                    this.setText("")
                }
            } else {
                with(v as EditText) {
                    val currentText = this.text.toString()
                    if (!(("([01]\\d|2[0-3]):[0-5]\\d".toRegex().containsMatchIn(currentText) && currentText.length == 5)
                                || ("([01]\\d|2[0-3])[0-5]\\d".toRegex().containsMatchIn(
                            currentText.padStart(
                                4,
                                '0'
                            )
                        ) && currentText.length <= 4))
                        || (currentText == "")
                    )
                        this.setText(this.hint)
                    else this.setText(
                        if (currentText.length < 5) "${currentText.padStart(
                            4,
                            '0'
                        ).slice(0..1)}:${currentText.padStart(4, '0').slice(2..3)}" else currentText
                    )
                }
                autoValues(view)
                updateTotalTime(totalTimeText, flighttOutStringField, flighttInStringField)
            }
        }
        flighttInStringField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    this.hint = this.text
                    this.setText("")
                }
            } else {
                with(v as EditText) {
                    val currentText = this.text.toString()
                    if (!(("([01]\\d|2[0-3]):[0-5]\\d".toRegex().containsMatchIn(currentText) && currentText.length == 5)
                                || ("([01]\\d|2[0-3])[0-5]\\d".toRegex().containsMatchIn(
                            currentText.padStart(
                                4,
                                '0'
                            )
                        ) && currentText.length <= 4))
                        || (currentText == "")
                    )
                        this.setText(this.hint)
                    else this.setText(
                        if (currentText.length < 5) "${currentText.padStart(
                            4,
                            '0'
                        ).slice(0..1)}:${currentText.padStart(4, '0').slice(2..3)}" else currentText
                    )
                }
                autoValues(view)
                updateTotalTime(totalTimeText, flighttOutStringField, flighttInStringField)
            }
        }


        flightOrigField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    this.hint = this.text
                    this.setText("")
                }
            } else {
                with(v as EditText) {
                    val currentText = this.text.toString()
                    val foundAirport = if (currentText != "") airportDb.searchAirport(currentText) else null
                    val foundAirportText: String
                    if (foundAirport != null) foundAirportText =
                        if (foundAirport.iata_code != "") foundAirport.iata_code else foundAirport.ident
                    else foundAirportText = v.hint.toString()
                    v.setText(foundAirportText)
                }
                autoValues(view)
            }
        }



        flightNameField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    hint = text
                    setText("")
                }
            } else {
                with(v as EditText) {
                    if (text.toString().isEmpty()) setText(hint)
                    else setText(namesWorker.getOneName(text.toString()) ?: text)
                }
            }
        }
        flightName2Field.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    hint = text
                    setText("")
                }
            } else {
                with(v as EditText) {
                    if (text.toString().isEmpty()) setText(hint)
                    else setText(namesWorker.getOneName(text.toString()) ?: text)
                }
            }
        }

        flightDestField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    this.hint = this.text
                    this.setText("")
                }
            } else {
                with(v as EditText) {
                    val currentText = this.text.toString()
                    val foundAirport = if (currentText.toString() != "") airportDb.searchAirport(currentText) else null
                    val foundAirportText: String
                    if (foundAirport != null) foundAirportText =
                        if (foundAirport.iata_code != "") foundAirport.iata_code else foundAirport.ident
                    else foundAirportText = v.hint.toString()
                    v.setText(foundAirportText)
                }
                autoValues(view)
            }

        }

        flightAircraftField.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as EditText) {
                    this.hint = this.text
                    this.setText("")
                }
            } else {
                with(v as EditText) {
                    val currentText = this.text.toString()
                    val foundAircraftList= if (currentText != "") aircraftDb.searchRegAndType(currentText, "") else emptyList()
                    val foundAircraft =
                        if (foundAircraftList.isNotEmpty()) foundAircraftList.first() else null
                    val foundAircraftText: String = if (foundAircraft != null) (if (flightSimulatorCheckbox.isChecked) foundAircraft.model else "${foundAircraft.registration}(${foundAircraft.model})") else v.hint.toString()
                    v.setText(foundAircraftText)
                }
            }
        }
        flightRemarksField.setOnEditorActionListener { thisview, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE){
                val imm: InputMethodManager = thisview.ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.hideSoftInputFromWindow(thisview.windowToken, 0)
                thisview.clearFocus()
            }
            true
        }
        // TODO GOT UNTIL HERE WITH MIGRATING TO NEW

        return view
    }

    override fun onPause(){
        super.onPause()
        if (saveChanges) {
            activity?.currentFocus?.clearFocus()
            val flightToSave = saveAllDataToFlight(this.view!!)

            // trigger onFileSavedListener if initialized
            onFileSavedListener?.fileSaved(flightToSave, flightToEdit)
        } else {
            activity?.currentFocus?.clearFocus()
            onFlightCancelledListener?.editCancelled(saveAllDataToFlight(this.view!!))
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        onViewDestroyedListener?.viewDestroyed()
        /*
        activity?.findViewById<View>(R.id.searchButton)?.fadeIn()
        activity?.findViewById<View>(R.id.addButton)?.fadeIn()
        */
    }


    private fun makeItSim(flightNumberText: TextView, flightFlightNumberField: EditText, origText: TextView, destText: TextView, flightOrigField: EditText, flightDestField: EditText,
                  flighttOutText: TextView, tInText: TextView, flighttInStringField: EditText, takeoffLandingText: TextView, flightTakeoffLandingField: EditText,
                  flightPicCheckbox: CheckBox, flightPilotFlyingCheckbox: CheckBox, flightPicusCheckbox: CheckBox, flightDualCheckbox: CheckBox){
        flighttOutText.text=getString(R.string.simtTime)
        //TODO probably more things will happen
    }
    private fun makeItNotSim(flightNumberText: TextView, flightFlightNumberField: EditText, origText: TextView, destText: TextView, flightOrigField: EditText, flightDestField: EditText,
                  flighttOutText: TextView, tInText: TextView, flighttInStringField: EditText, takeoffLandingText: TextView, flightTakeoffLandingField: EditText,
                  flightPicCheckbox: CheckBox, flightPilotFlyingCheckbox: CheckBox, flightPicusCheckbox: CheckBox, flightDualCheckbox: CheckBox){
        //TODO do the reverse of makeItSim()
    }


    private fun autoValues(view: View){
        val flighttOutStringField: EditText = view.findViewById(R.id.flighttOutStringField)
        val flightDateField: EditText = view.findViewById(R.id.flightDateField)
        val flighttInStringField: EditText = view.findViewById(R.id.flighttInStringField)
        val flightOrigField: EditText = view.findViewById(R.id.flightOrigField)
        val flightDestField: EditText = view.findViewById(R.id.flightDestField)
        val flightTakeoffLandingField: EditText = view.findViewById(R.id.flightTakeoffLandingField)
        val flightAircraftField: EditText = view.findViewById(R.id.flightAircraftField)
        val flightPilotFlyingCheckbox: CheckBox = view.findViewById(R.id.flightPilotFlyingCheckbox)
        val flightSimulatorCheckbox: CheckBox = view.findViewById(R.id.flightSimulatorCheckbox)
        val hiddenLandingHelper: TextView = view.findViewById(R.id.hiddenLandingHelper)
        val autoFillCheckBox: CheckBox = view.findViewById(R.id.autoFillCheckBox)
        val hiddenNightTime: TextView = view.findViewById(R.id.hiddenNightTime)
        val hiddenIfrTime: TextView = view.findViewById(R.id.hiddenIfrTime)

        if (autoFillCheckBox.isChecked) {
            if (flightSimulatorCheckbox.isChecked) {
                hiddenLandingHelper.text = "0"
                hiddenIfrTime.text = "0"
                hiddenNightTime.text = "0"
                return
            } else {
                var duration: Duration
                if (flighttOutStringField.text.toString().isNotEmpty() && flighttInStringField.text.toString().isNotEmpty()) {
                    duration = Duration.between(flighttOutStringField.text.toString().makeLocalTime(), flighttInStringField.text.toString().makeLocalTime())
                    if (duration.seconds < 0) duration = duration.plusDays(1)
                } else return
                // Calculate landings:
                val twilightCalculator = TwilightCalculator(
                    LocalDateTime.of(
                        flightDateField.text.toString().makeLocalDate(),
                        flighttOutStringField.text.toString().makeLocalTime()
                    )
                )
                val orig = airportDb.searchAirport(flightOrigField.text.toString())
                val dest = airportDb.searchAirport(flightDestField.text.toString())
                if (orig == null || dest == null) return

                if (flightPilotFlyingCheckbox.isChecked) { // DTDLNTNLAL // 1.00.00.00.00.00 / 0/2/4/6/8 zeros
                    var takeoffLandings: Long = if (twilightCalculator.itIsDayAt(
                            orig,
                            flighttOutStringField.text.toString().makeLocalTime()
                        )
                    ) 100000000 else 1000000
                    takeoffLandings += if (twilightCalculator.itIsDayAt(
                            orig,
                            flighttOutStringField.text.toString().makeLocalTime()
                        )
                    ) 10000 else 100
                    hiddenLandingHelper.text = takeoffLandings.toString()
                } else hiddenLandingHelper.text = "0"
                val landingData = hiddenLandingHelper.text.toString().toLong() // DTDLNTNLAL // 1.00.00.00.00.00 / 2/4/6/8/10 zeros
                val autoland: Int = (landingData % 100).toInt()
                val takeoffDay: Int = ((landingData%10000000000)/100000000).toInt()
                val takeoffNight: Int = ((landingData%100000000)/1000000).toInt()
                val landingDay: Int = ((landingData%1000000)/10000).toInt()
                val landingNight: Int = ((landingData%10000)/100).toInt()
                flightTakeoffLandingField.setText("${takeoffDay+takeoffNight}/${landingDay+landingNight}")


                //calculate nighttime and IFR time
                hiddenNightTime.text = twilightCalculator.minutesOfNight(
                    airportDb.searchAirport(flightOrigField.text.toString()),
                    airportDb.searchAirport(flightDestField.text.toString()),
                    flighttOutStringField.text.toString().makeLocalTime(),
                    flighttInStringField.text.toString().makeLocalTime()
                ).toString()
                Log.d("nightTime:", "nighttime = ${hiddenNightTime.text}")
                hiddenIfrTime.text = if (aircraftDb.searchRegAndType(reg = flightAircraftField.text.toString()
                        .slice(0 until flightAircraftField.text.toString().indexOf("("))).firstOrNull()
                        ?.isIfr ?: 0 > 0) duration.toMinutes().toString() else "0"
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateTotalTime(totalTime: TextView, tOut: EditText, tIn: EditText){
        if (tOut.text.toString().isNotEmpty() && tIn.text.toString().isNotEmpty()) {
            var duration: Duration = Duration.between(tOut.text.toString().makeLocalTime(), tIn.text.toString().makeLocalTime())
            if (duration.seconds < 0) duration = duration.plusDays(1)
            totalTime.text = "${duration.seconds/3600}:${((duration.seconds%3600)/60).toString().padStart(2,'0')}"
        }
    }

    fun populateNames(flightList: List<Flight>){
        Log.d("populateNames", "got ${flightList.size} flights")
        var names: List<String> = listOf("SELF")
        flightList.forEach {
            names += unpackNames(it.name, it.name2) ?: emptyList()
        }
        Log.d("populateNames", "got ${names.size} names")
        this.allNames = names
        namesWorker.nameList = names
    }

    private fun unpackNames(vararg nameStrings: String): List<String>? {
        var names: List<String> = emptyList()
        for (nameString in nameStrings) {
            if (',' in nameString) {
                var text = nameString
                while (',' in text) {
                    val name = text.slice(0 until text.indexOf(','))
                    text = nameString.slice(text.indexOf(',') until text.length).trim(',', ' ')
                    if (name.isNotEmpty() && name != "SELF") names += name
                }
                if (text.isNotEmpty()) names += text
            } else if (nameString.isNotEmpty() && nameString != "SELF") names += nameString
        }
        return if (names.isEmpty()) null else names
    }

}



*/
