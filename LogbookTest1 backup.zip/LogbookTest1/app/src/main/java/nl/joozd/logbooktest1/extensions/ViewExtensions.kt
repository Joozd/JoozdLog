package nl.joozd.logbooktest1.extensions

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.graphics.Typeface
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView

val View.ctx: Context
    get() = context

/*
extends a view (assumes said View's visibility is "gone", quickly fade that in, and
 */

fun View.fadeIn(vararg fadeOutView: View) {
    var shortAnimationDuration: Int = 0
    shortAnimationDuration = resources.getInteger(android.R.integer.config_shortAnimTime)
    this.apply {
        // Set the content view to 0% opacity but visible, so that it is visible
        // (but fully transparent) during the animation.
        alpha = 0f
        visibility = View.VISIBLE

        // Animate the content view to 100% opacity, and clear any animation
        // listener set on the view.
        animate()
            .alpha(1f)
            .setDuration(shortAnimationDuration.toLong())
            .setListener(null)
    }
    for (v in fadeOutView){
        v.animate()
            .alpha(0f)
            .setDuration(shortAnimationDuration.toLong())
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    v.visibility = View.GONE
                }
            })
    }
}

fun View.fadeOut() {
    var shortAnimationDuration: Int = 0
    shortAnimationDuration = resources.getInteger(android.R.integer.config_shortAnimTime)
    this.apply {
        // Animate the content view to 0% opacity
        animate()
            .alpha(0f)
            .setDuration(shortAnimationDuration.toLong())
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    visibility = View.GONE
                }
            })
    }
}

fun View.beGone() {
    this.apply { visibility=View.GONE }
}

fun TextView.setLayoutToOff(){
    val color= (this.textColor % 0x01000000)
    this.textColor=(0x20000000 + color)
    this.setTypeface(null, Typeface.NORMAL)
}

fun TextView.setLayoutToOn(){
    val color= (this.textColor % 0x01000000)
    this.textColor=(0xCC000000 + color)
    this.setTypeface(null, Typeface.BOLD)
}


var TextView.textColor: Long
    get() {
        return this.currentTextColor.toLong()
    }
    set(value: Long) {
        this.setTextColor(value.toInt())
    }

fun EditText.onFocusChange(v: View, hasFocus: Boolean){
    if (hasFocus){
        this.hint = this.text
        this.setText("")
    }
    else{
        if (this.text.toString() == "") {
            this.setText(this.hint)
        }
    }
}

fun EditText.onTextChanged(onTextChanged: (String) -> Unit) {
    this.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        }

        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            onTextChanged.invoke(p0.toString())
        }

        override fun afterTextChanged(editable: Editable?) {
        }
    })
}