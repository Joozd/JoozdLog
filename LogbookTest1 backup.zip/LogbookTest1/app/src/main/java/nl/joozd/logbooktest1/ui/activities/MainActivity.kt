package nl.joozd.logbooktest1.ui.activities

import android.graphics.Typeface
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main_new.*

import nl.joozd.logbooktest1.R

import nl.joozd.logbooktest1.comm.Comms
import nl.joozd.logbooktest1.data.Aircraft
import nl.joozd.logbooktest1.data.BalanceForward
import nl.joozd.logbooktest1.data.Flight

import nl.joozd.logbooktest1.data.db.FlightDb
import nl.joozd.logbooktest1.ui.adapters.FlightsAdapter

import org.jetbrains.anko.doAsync
import nl.joozd.logbooktest1.data.db.AircraftDb
import nl.joozd.logbooktest1.data.db.AirportDb
import nl.joozd.logbooktest1.data.db.BalanceForwardDb
import nl.joozd.logbooktest1.data.enumclasses.ThingsToSync
import nl.joozd.logbooktest1.data.utils.*
import nl.joozd.logbooktest1.extensions.*
import nl.joozd.logbooktest1.ui.fragments.BalanceForwardFragment
import nl.joozd.logbooktest1.ui.fragments.EditFlightNew
import nl.joozd.logbooktest1.ui.fragments.TotalTimes
import nl.joozd.logbooktest1.utils.FlightSearcher
import nl.joozd.logbooktest1.utils.listeners.UndoSaveFlightListener
import org.jetbrains.anko.toast


class MainActivity : AppCompatActivity() {
    class ShowMenuListener(private val f: () -> Unit){
        fun go(){
            f()
        }
    }

    val fragmentManager = supportFragmentManager!!

    private val flightDb = FlightDb()
    private val airportDb = AirportDb()
    private val aircraftDb = AircraftDb()
    private val balanceForwardDb = BalanceForwardDb()
    var allFlights: List<Flight> = emptyList()
    var resetFlights: List<Flight> = emptyList()
    var allAircraft: List<Aircraft> = emptyList()
    var icaoIataPairs: List<Pair<String, String>> = emptyList()
    private var filteredFlights: List<Flight> = allFlights
    private val flightsAdapter: FlightsAdapter = FlightsAdapter(allFlights) { showFlight(it) }
    private val flightSearcher = FlightSearcher(flightDb, airportDb, aircraftDb)
    private var namesWorker:NamesWorker = NamesWorker()
    private var showTotalTimesMenuListener: ShowMenuListener? = null
    private var showBalanceForwardListener: ShowMenuListener? = null
    private var totalTimesFragment: TotalTimes? = null
    private var balanceForwardFragment: BalanceForwardFragment? = null
    private var balancesForward: List<BalanceForward> = emptyList()

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) = when (item.itemId) {
        /*R.id.menu_rebuild -> {
            doAsync {
                allFlights = Comms().rebuildFromServer()
                runOnUiThread {
                    flightDb.clearDB()
                    flightDb.saveFlights(allFlights)
                    toast("Database rebuilt. please restart ofzo")
                }
            }
            true
        } */
        R.id.menu_total_times -> {
            showTotalTimesMenuListener?.go()
            true
        }
        R.id.menu_balance_forward -> {
            showBalanceForwardListener?.go()
            true
        }
        R.id.app_bar_search -> {
            if (searchField.visibility == View.VISIBLE){
                searchField.visibility = View.GONE
                addButton.show()
            }
            else {
                if (flightSearcher.initialized) {
                    searchField.visibility = View.VISIBLE
                    addButton.hide()
                }
                else toast("please wait, initializing search")
            }
            true
        }
        else -> false

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        allFlights = (flightDb.requestAllFlights()).sortedBy { it.tOut }.asReversed()
        balancesForward=balanceForwardDb.requestAllBalanceForwards()
        allAircraft = (aircraftDb.requestAllAircraft())

        // start initializing search functionality
        doAsync {
            flightSearcher.init(allFlights)
            namesWorker.initialize(allFlights)  // put all names of all flights into namesWorker
        }

        // TODO preferences check if this is wanted

        setTheme(R.style.AppTheme)

        setContentView(R.layout.activity_main_new) // .activity_main_with_search
        setSupportActionBar(findViewById(R.id.my_toolbar))


        flightsList.layoutManager = LinearLayoutManager(this)
        flightsList.adapter = flightsAdapter
        flightsAdapter.flights=allFlights
        supportActionBar?.title="${flightsAdapter.flights.size} Flights"

        // start synching with server
        doAsync {
            syncWithServer(flightsAdapter, listOf(ThingsToSync.FLIGHTS, ThingsToSync.AIRCRAFT, ThingsToSync.AIRPORTS))
        }

        // start initializing total times
        balanceForwardFragment=BalanceForwardFragment()
        totalTimesFragment=TotalTimes()
        doAsync{
            totalTimesFragment?.fillData(allFlights, balancesForward)
        }

        addButton.setOnClickListener(View.OnClickListener {
            showFlight(null, true)
        })

        var nameSearchString: String? = null
        var airportSearchString: String? = null
        var aircraftSearchString: String? = null

        pilotNameSearch.onTextChanged {
            nameSearchString = if (it.isNotEmpty()) it else null
            flightsAdapter.flights=flightSearcher.search(nameSearchString, aircraftSearchString, airportSearchString)
            supportActionBar?.title="${flightsAdapter.flights.size} Flights"
        }
        airportSearch.onTextChanged {
            airportSearchString = if (it.isNotEmpty()) it else null
            flightsAdapter.flights=flightSearcher.search(nameSearchString, aircraftSearchString, airportSearchString)
            supportActionBar?.title="${flightsAdapter.flights.size} Flights"
        }
        aircraftSearch.onTextChanged {
            aircraftSearchString = if (it.isNotEmpty()) it else null
            flightsAdapter.flights=flightSearcher.search(nameSearchString, aircraftSearchString, airportSearchString)
            supportActionBar?.title="${flightsAdapter.flights.size} Flights"
        }

        showTotalTimesMenuListener = ShowMenuListener{
            // TODO Make some things happen in menu and action bar so app wont crash upon doing this twice etc.
            totalTimesFragment?.let {
                totalTimesFragment!!.onStart = TotalTimes.OnStartListener{
                    addButton.hide()
                    // TODO change menu, clear and close search if open, remove search option
                }
                totalTimesFragment!!.onStop = TotalTimes.OnStopListener{
                    addButton.show()
                    // TODO change menu, add search option
                }

                if (totalTimesFragment!!.initialized) {
                    fragmentManager.beginTransaction()
                        .add(R.id.mainBelowMenubar, totalTimesFragment!!)
                        .addToBackStack(null)
                        .commit()
                } else {
                    toast("too soon!")
                }
            }
        }
        showBalanceForwardListener = ShowMenuListener{
            balanceForwardFragment?.let{
                balanceForwardFragment!!.balancesForward=balancesForward
                balanceForwardFragment!!.onStart = BalanceForwardFragment.OnStartListener{
                    addButton.hide()
                    // TODO change menu, clear and close search if open, remove search option
                }
                balanceForwardFragment!!.onStop = BalanceForwardFragment.OnStopListener{
                    addButton.show()
                    // TODO change menu, add search option
                }
                    fragmentManager.beginTransaction()
                        .add(R.id.mainBelowMenubar, balanceForwardFragment!!)
                        .addToBackStack(null)
                        .commit()

            }
        }


    }


    private fun syncWithServer(flightsAdapter: FlightsAdapter, thingsToSync: List<ThingsToSync>) {
/*        //TODO tempo to fix stuff
        val fixedFlights: MutableList<Flight> = mutableListOf()
        Log.d("fixing", "${allFlights.size} flights")
        var counter = 0
        allFlights.forEach {
            fixedFlights.add(flightAirportToIcao(it).copy(changed = 1))
            counter += 1
            if (counter %100 == 1)
                Log.d("Count", "$counter")
        }
        allFlights=fixedFlights.toList()
        flightDb.saveFlights(allFlights)
        Log.d("fixed", "${fixedFlights.size} flights")
        Log.d("check", "${allFlights.size} flights")
        */
        val comms = Comms()
        if (ThingsToSync.FLIGHTS in thingsToSync) {
            Log.d("SyncWithServer:", "FLIGHTS")
            val newFlights = comms.getUpdates()
            if (newFlights.isNotEmpty()) {
                flightDb.saveFlights(airportsToIcao(newFlights))
                allFlights = (flightDb.requestAllFlights()).sortedBy { it.tOut }.asReversed()
                runOnUiThread{
                    toast("Updated flights from server")
                    flightsAdapter.flights=allFlights
                }
            }
            if (comms.sendUpdates(allFlights)) {
                val updatedflights = (allFlights.filter { it.changed > 0 })
                if (updatedflights.isNotEmpty()) {
                    var flightsToSave = emptyList<Flight>()
                    updatedflights.forEach {
                        flightsToSave += it.copy(changed = 0)
                    }
                    flightDb.saveFlights(airportsToIcao(flightsToSave))
                    runOnUiThread{
                        toast("sent updated flights to server")
                    }
                }
            }
            if (!comms.checkifsynched(flightDb.getSumOfAllIds())) {
                runOnUiThread {
                    toast("out of sync! trying to resync...")
                }
                flightDb.clearDB()
                flightDb.saveFlights(airportsToIcao(comms.rebuildFromServer()))
                allFlights = (flightDb.requestAllFlights()).sortedBy { it.tOut }.asReversed()
                runOnUiThread {
                    flightsAdapter.flights = allFlights
                }
            }
            var deletedFlights=false
            allFlights.forEach {
                if (it.DELETEFLAG>0 && it.changed == 0) flightDb.deleteFlight(it); deletedFlights=true
            }
            if (deletedFlights) {
                allFlights = (flightDb.requestAllFlights()).sortedBy { it.tOut }.asReversed()
                runOnUiThread {
                    flightsAdapter.flights = allFlights
                }
            }
        }

        if (ThingsToSync.AIRCRAFT in thingsToSync) {
            Log.d("SyncWithServer:", "AIRCRAFT")
            val newAircraft = comms.checkAircraft(aircraftDb.highestId)
            runOnUiThread{
                newAircraft?.let { toast("New aircraft downloaded") }
            }
            newAircraft?.let {aircraftDb.saveAircraft(it)}
        }

        if (ThingsToSync.AIRPORTS in thingsToSync) {
            Log.d("SyncWithServer:", "AIRPORTS")
            val newAirports = comms.checkAirports(airportDb.highestId)
            runOnUiThread {
                newAirports?.let { toast("New airports downloaded") }
            }
            newAirports?.let { airportDb.saveAirports(it) }
            comms.close()
        }
    }

    private fun showFlight(flight: Flight?, newFlight: Boolean = false) { // new flight gets (null, true)
        val flightEditor = EditFlightNew()
/*        flightEditor.onViewDestroyedListener = EditFlight.OnViewDestroyedListener {
            addButton.fadeIn()
            supportActionBar?.show()
        }
*/
        flightEditor.onSave = EditFlightNew.OnSave { flightToSave, oldFlight ->
            flightDb.saveFlight(flightToSave)
            flightsAdapter.insertFlight(flightToSave)
            supportActionBar?.title = "${flightsAdapter.flights.size} Flights"
            flightSearcher.addFlight(flightToSave)
            namesWorker.addFlight(flightToSave)
            allFlights =
                (allFlights.filter { it.flightID != flightToSave.flightID } + flightToSave).sortedBy { it.tOut }
                    .asReversed()
            totalTimesFragment?.fillData(allFlights, balancesForward)

            val snackbar = Snackbar.make(mainActivityLayout, "SAVED FLIGHT!", Snackbar.LENGTH_LONG)
            snackbar.setAction(
                "Undo",
                UndoSaveFlightListener(oldFlight, flightDb, flightsAdapter, addButton, flightSearcher) // THIS WILL MAKE TOTALS AND STUFF INCORRECT FOR THE REST OF THE SESSION
            )
            snackbar.view.setBackgroundColor(getColorFromAttr(R.attr.colorPrimaryDark))
            val snackbarTextView = snackbar.view.findViewById<TextView>(android.support.design.R.id.snackbar_text)
            snackbarTextView.setTypeface(null, Typeface.BOLD)
            snackbar.show()
            addButton.fadeIn()
            supportActionBar?.show()
        }

        flightEditor.onCancel = EditFlightNew.OnCancel { canceledFlight, _ ->
            val snackbar = Snackbar.make(mainActivityLayout, "CANCELLED!", Snackbar.LENGTH_LONG)
            snackbar.setAction("Continue", View.OnClickListener { showFlight(canceledFlight) })
            snackbar.view.setBackgroundColor(getColorFromAttr(R.attr.colorPrimaryDark))
            val snackbarTextView = snackbar.view.findViewById<TextView>(android.support.design.R.id.snackbar_text)
            snackbarTextView.setTypeface(null, Typeface.BOLD)
            snackbar.show()
            addButton.fadeIn()
            supportActionBar?.show()
        }
        flightEditor.lastCompletedFlight = mostRecentCompleteFlight(allFlights)
        flightEditor.flight =
            flight ?: reverseFlight(flightEditor.lastCompletedFlight!!, flightDb.highestId + 1) ?: makeEmptyFlight(
                flightDb.highestId + 1
            )
        if (namesWorker.isInitialized) flightEditor.namesWorker = namesWorker
        else {
            namesWorker.initializationListener = NamesWorker.InitializationListener {
                flightEditor.namesWorker = namesWorker
            } // if (or when) namesWorker is done making its names, put it into  EditFlight fragment
        }

        fragmentManager.beginTransaction()
            .add(R.id.mainActivityLayout, flightEditor)
            .addToBackStack(null)
            .commit()
        addButton.fadeOut()
        supportActionBar?.hide()
    }
}
