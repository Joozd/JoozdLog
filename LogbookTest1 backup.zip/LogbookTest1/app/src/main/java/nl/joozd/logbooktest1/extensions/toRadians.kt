package nl.joozd.logbooktest1.extensions

fun Double.toRadians() = this*Math.PI/180