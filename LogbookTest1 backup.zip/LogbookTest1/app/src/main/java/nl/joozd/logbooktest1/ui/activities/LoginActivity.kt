package nl.joozd.logbooktest1.ui.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import nl.joozd.logbooktest1.R

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
    }
}
