package nl.joozd.logbooktest1.data

import java.time.Duration
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeFormatter.ISO_DATE_TIME


data class Flight(
    val flightID: Int,
    val orig: String,
    val dest: String,
    val tOutString: String,
    val tInString: String,
    val nightTime: Int,
    val ifrTime:Int,
    val simTime: Int,
    val aircraft: String,
    val registration: String,
    val name: String,
    val name2: String,
    val takeOffDay: Int,
    val takeOffNight: Int,
    val landingDay: Int,
    val landingNight: Int,
    val autoLand: Int,
    val flightNumber: String,
    val remarks: String,
    val isPIC: Int,
    val isPICUS: Int,
    val isCoPilot: Int,
    val isDual: Int,
    val isInstructor: Int,
    val isSim: Int,
    val isPF: Int,
    val isPlanned: Int,
    val changed: Int,
    val autoFill: Int,
    val DELETEFLAG: Int
){
    private val dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy")
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm") // should always be in Z
    // "2011-12-03T10:15:00" is the way to send tInString and tOutString
    // nightTime, ifrTime are number of minutes
    // isPIC etc are '0' for false and '1' for true
    // TODO ifrTime "0" is standard by aircraft type
    val allNames: String
    val takeoffLanding: String
    init{
        var allNamesBuilder=name
        if (name2 != "") allNamesBuilder += ", $name2"
        allNames = allNamesBuilder
        takeoffLanding = "${takeOffNight+takeOffDay}/${landingNight+landingDay}"
    }

    val tOut: LocalDateTime = LocalDateTime.parse(tOutString, ISO_DATE_TIME)
    val tIn: LocalDateTime = LocalDateTime.parse(tInString, ISO_DATE_TIME)
    val timeOut: String = tOut.format(timeFormatter)
    val timeIn: String = tIn.format(timeFormatter)

    val duration: Duration = Duration.between(tOut, tIn)

    val pic = isPIC > 0
    val picus = isPICUS > 0
    val coPilot = isCoPilot > 0
    val dual = isDual > 0
    val instructor = isInstructor > 0
    val sim = isSim > 0
    val pf = isPF > 0
    val planned = isPlanned > 0 // only planned flights should be deletable, not planned is flown

    val date: String = tOut.format(dateFormatter)

    //val flightTimes = "$timeOut-$timeIn"
    val totalTime = "${duration.seconds/3600}:${((duration.seconds%3600)/60).toString().padStart(2,'0')} hrs"
    val simTimeString = "${simTime/60}:${simTime%60} hrs"

    // name2 is a comma separated string of a million names
}