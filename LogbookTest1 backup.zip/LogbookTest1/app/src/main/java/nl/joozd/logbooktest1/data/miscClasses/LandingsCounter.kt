package nl.joozd.logbooktest1.data.miscClasses

data class LandingsCounter(var takeOffDay: Int = 0, var landingDay: Int = 0, var takeOffNight: Int = 0, var landingNight: Int = 0, var autoland: Int = 0) {
}