package nl.joozd.logbooktest1.ui.adapters

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_aircraft_picker.*
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.Aircraft
import nl.joozd.logbooktest1.extensions.ctx

class AircraftPickerAdapter(private var allAircraft: List<Aircraft>, private val itemClick: (Aircraft) -> Unit): RecyclerView.Adapter<AircraftPickerAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AircraftPickerAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.ctx).inflate(R.layout.item_aircraft_picker, parent, false)
        return ViewHolder(view, itemClick)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindAircraft(allAircraft[position])
    }

    override fun getItemCount(): Int = allAircraft.size

    fun updateData(newFlights: List<Aircraft>) {
        allAircraft = newFlights
        this.notifyDataSetChanged()
    }

    class ViewHolder(override val containerView: View, private val itemClick: (Aircraft) -> Unit) :
        RecyclerView.ViewHolder(containerView),
        LayoutContainer {

        fun bindAircraft(aircraft: Aircraft) {
            with(aircraft) {
                registrationText.text = registration
                makeModelText.text = "$manufacturer $model"
                itemView.setOnClickListener {
                    itemClick(this)
                }
            }

        }
    }
}
