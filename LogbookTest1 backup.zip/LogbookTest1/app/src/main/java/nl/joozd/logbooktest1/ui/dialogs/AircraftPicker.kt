package nl.joozd.logbooktest1.ui.dialogs

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.Aircraft
import nl.joozd.logbooktest1.data.db.AircraftDb
import nl.joozd.logbooktest1.extensions.getColorFromAttr
import nl.joozd.logbooktest1.ui.adapters.AircraftPickerAdapter
import nl.joozd.logbooktest1.extensions.onTextChanged


class AircraftPicker : Fragment() {
    class FlightSelectedListener (private val f: (aircraft: Aircraft) -> Unit){
        fun flightSelected(aircraft: Aircraft){
            f(aircraft)
        }
    }


    private val aircraftDB = AircraftDb()
    var allAircraft: List<Aircraft> = emptyList()
    var viewToUpdate: EditText? = null
    private var pickedAircraft: Aircraft? = null
    var flightSelectedListener: FlightSelectedListener? = null

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        allAircraft = aircraftDB.requestAllAircraft()
    }

    @SuppressLint("SetTextI18n")
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.picker_aircraft, container,            false)
        val aircraftPickerAdapter = AircraftPickerAdapter(allAircraft) { putItIn(it, view) }
        val aircraftPickerList = view.findViewById(R.id.aircraftPickerList) as RecyclerView
        val aircraftPickerLayout: View = view.findViewById(R.id.aircraftPickerLayout)
        val aircraftPickerCancel: View = view.findViewById(R.id.aircraftPickerCancel)
        val aircraftPickerOk: View = view.findViewById(R.id.aircraftPickerOk)
        val headText: TextView = view.findViewById(R.id.pickedAircraftText)
        val makeModelText: TextView = view.findViewById(R.id.makeModelText)
        val engineText: TextView = view.findViewById(R.id.engineText)
        val aircraftPickerTopHalf: ConstraintLayout = view.findViewById(R.id.aircraftPickerTopHalf)

        (aircraftPickerTopHalf.background as GradientDrawable).colorFilter = PorterDuffColorFilter(activity!!.getColorFromAttr(android.R.attr.colorPrimary), PorterDuff.Mode.SRC_IN)
        viewToUpdate.let{
            pickedAircraft = findAircraftByReg(viewToUpdate?.text.toString().slice(0 until viewToUpdate?.text.toString().indexOf("(")))
            if (pickedAircraft == null) {
                headText.text = viewToUpdate?.text.toString().slice(0 until viewToUpdate?.text.toString().indexOf("("))
                makeModelText.text = ""
                engineText.text = ""
            } else putItIn(pickedAircraft!!, view)
        }



        aircraftPickerList.layoutManager = LinearLayoutManager(context)
        aircraftPickerList.adapter = aircraftPickerAdapter

        aircraftPickerLayout.setOnClickListener { fragmentManager?.popBackStack() }

        aircraftPickerCancel.setOnClickListener { fragmentManager?.popBackStack() }

        aircraftPickerOk.setOnClickListener {
            pickedAircraft?.let { flightSelectedListener?.flightSelected(it) }
            fragmentManager?.popBackStack()
        }

        val regField: EditText = view.findViewById(R.id.aircraftRegistrationPicker)
        val typeField: EditText = view.findViewById(R.id.aircraftTypePicker)
        regField.onTextChanged {
            aircraftPickerAdapter.updateData(filterAircraftByType(typeField.text.toString(), filterAircraftByReg(it, allAircraft)))
        }
        typeField.onTextChanged {
            aircraftPickerAdapter.updateData(filterAircraftByType(it, filterAircraftByReg(regField.text.toString(), allAircraft)))
        }
        return view
    }

    @SuppressLint("SetTextI18n")
    fun putItIn(aircraft: Aircraft, v: View){
        pickedAircraft = aircraft
        val headText: TextView = v.findViewById(R.id.pickedAircraftText)
        val makeModelText: TextView = v.findViewById(R.id.makeModelText)
        val engineText: TextView = v.findViewById(R.id.engineText)

        headText.text = aircraft.registration
        makeModelText.text = "${aircraft.manufacturer} ${aircraft.model}"
        engineText.text = "${if (aircraft.me == 1)"ME" else "SE"} ${aircraft.engine_type}"


    }
    private fun findAircraftByReg(query: String, aircraftList: List<Aircraft> = allAircraft): Aircraft? = aircraftList.firstOrNull{it.registration.contains(query)}
    private fun filterAircraftByType(query: String, aircraftList: List<Aircraft> = allAircraft): List<Aircraft> = if (query.isNotEmpty()) aircraftList.filter{it.model.contains(query) || it.manufacturer.contains(query)} else aircraftList
    private fun filterAircraftByReg(query: String, aircraftList: List<Aircraft> = allAircraft): List<Aircraft> = if (query.isNotEmpty()) aircraftList.filter{it.registration.contains(query)} else aircraftList
}
