package nl.joozd.logbooktest1.data.enumclasses

enum class ThingsToSync {
    FLIGHTS, AIRCRAFT, AIRPORTS
}