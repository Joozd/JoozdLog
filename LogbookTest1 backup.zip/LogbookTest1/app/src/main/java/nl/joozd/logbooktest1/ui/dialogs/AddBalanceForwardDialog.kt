package nl.joozd.logbooktest1.ui.dialogs

import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.design.widget.TextInputEditText
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.BalanceForward
import nl.joozd.logbooktest1.extensions.getColorFromAttr
import nl.joozd.logbooktest1.extensions.toInt
import org.jetbrains.anko.find

class AddBalanceForwardDialog: Fragment() {
    class OnSave(private val f: (balanceForward: BalanceForward) -> Unit){
        fun save (balanceForward: BalanceForward) {
            f(balanceForward)
        }
    }

    private lateinit var thisView: View
    var onSave: OnSave? = null
    var balanceForward=BalanceForward("Joozd is cool", 0,0,0,0,0,0,0,0,0,0,0,0)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        thisView = inflater.inflate(R.layout.add_balance_forward_dialog, container, false)

        val flightInfoText: TextView = thisView.findViewById(R.id.flightInfoText)
        val background: ConstraintLayout = thisView.findViewById(R.id.background)

        val logbookNameText: TextInputEditText = thisView.findViewById(R.id.logbookNameText)
        val aircraftTimeText: TextInputEditText = thisView.findViewById(R.id.aircraftTimeText)
        val simulatorTimeText: TextInputEditText = thisView.findViewById(R.id.simulatorTimeText)
        val takeoffDayText: TextInputEditText = thisView.findViewById(R.id.takeoffDayText)
        val takeoffNightText: TextInputEditText = thisView.findViewById(R.id.takeoffNightText)
        val landingDayText: TextInputEditText = thisView.findViewById(R.id.landingDayText)
        val landingNightText: TextInputEditText = thisView.findViewById(R.id.landingNightText)
        val nightTimeText: TextInputEditText = thisView.findViewById(R.id.nightTimeText)
        val ifrTimeText: TextInputEditText = thisView.findViewById(R.id.ifrTimeText)
        val picText: TextInputEditText = thisView.findViewById(R.id.picText)
        val copilotText: TextInputEditText = thisView.findViewById(R.id.copilotText)
        val dualText: TextInputEditText = thisView.findViewById(R.id.dualText)
        val instructorText: TextInputEditText = thisView.findViewById(R.id.instructorText)

        val cancelButton: TextView = thisView.findViewById(R.id.cancelButton)
        val saveButton: TextView = thisView.findViewById(R.id.saveButton)

        logbookNameText.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                with(v as TextInputEditText) {
                    v.selectAll()
                }
            } else {
                balanceForward = balanceForward.copy(logbookName = logbookNameText.text.toString())
            }
        }

        (flightInfoText?.background as GradientDrawable).colorFilter = PorterDuffColorFilter(activity!!.getColorFromAttr(android.R.attr.colorPrimary), PorterDuff.Mode.SRC_IN) // set background color to bakground with rounded corners

        background.setOnClickListener { fragmentManager?.popBackStack() }

        cancelButton.setOnClickListener { fragmentManager?.popBackStack() }

        saveButton.setOnClickListener {

            onSave?.save(balanceForward)
            fragmentManager?.popBackStack()
        }
        return thisView
    }
}