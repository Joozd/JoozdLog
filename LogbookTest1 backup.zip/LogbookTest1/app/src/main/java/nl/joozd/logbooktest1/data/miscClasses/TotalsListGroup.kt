package nl.joozd.logbooktest1.data.miscClasses

// The idea is that the ExpandableListAdapter for total times wil get a list of TotalsListGroups, each containing a header name, and a list of items.
// Each item consists (for now) of a name (eg. ME-Piston) and a value in minutes (eg. 523)

class TotalsListItem(val valueName: String, val totalTime: Long)

class TotalsListGroup(val title: String, val items: List<TotalsListItem>)