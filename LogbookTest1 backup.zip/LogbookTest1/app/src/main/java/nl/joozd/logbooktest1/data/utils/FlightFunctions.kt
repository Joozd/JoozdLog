package nl.joozd.logbooktest1.data.utils

import nl.joozd.logbooktest1.data.Flight
import nl.joozd.logbooktest1.data.db.FlightDb
import nl.joozd.logbooktest1.utils.toDateString
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


fun today(): String = LocalDate.now().format(DateTimeFormatter.ISO_DATE)

fun makeEmptyFlight(id: Int): Flight = Flight(id, "", "", "${today()}T12:00:00", "${today()}T13:00:00", 0, 0,0,
        "", "", "", "",  0, 0, 0,
        0, 0, "", "", 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0
    )

// will return most recent flight that is not isPlanned
fun mostRecentCompleteFlight(flights: List<Flight>): Flight = flights.maxBy { if (it.isPlanned == 0) it.tOut else LocalDateTime.of(1980, 11, 27, 10, 0) } ?: flights[0]

// returns a flight that is the return flight of the flight given (ie dest and orig swapped, flightnr plus one)
fun reverseFlight(flight: Flight, newID: Int): Flight{
    var flightnumber= flight.flightNumber
    var flightnumberDigits = ""
    while (flightnumber.last().isDigit()){
        flightnumberDigits = flightnumber.last() + flightnumberDigits
        flightnumber = flightnumber.dropLast(1)
    }
    flightnumber = if (flightnumberDigits.isEmpty()) flightnumber else flightnumber+(flightnumberDigits.toLong() + 1).toString()
    return flight.copy(flightID = newID, orig=flight.dest, dest=flight.orig, flightNumber = flightnumber)
}


