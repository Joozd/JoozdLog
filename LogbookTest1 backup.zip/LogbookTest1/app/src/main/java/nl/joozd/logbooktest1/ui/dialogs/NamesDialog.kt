package nl.joozd.logbooktest1.ui.dialogs

import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.utils.NamesWorker
import nl.joozd.logbooktest1.extensions.getColorFromAttr
import nl.joozd.logbooktest1.extensions.onTextChanged
import nl.joozd.logbooktest1.ui.adapters.NamesPickeradapter

class NamesDialog: Fragment() {
    class NamesSelectedListener(private val f: (names: String) -> Unit){
        fun namesSelected(names: String){
            f(names)
        }
    }
    var onSelectListener: NamesSelectedListener? = null
    var namesWorker: NamesWorker? = null        // to be filled before inflating with an initialized NamesWorker
    var selectOnlyOne=false
    var selectedName = ""
    var previousNames = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.dialog_names, container, false)

        val namesPickerList: RecyclerView = view.findViewById(R.id.namesPickerList)
        val selectedNames: EditText = view.findViewById(R.id.selectedNames)
        val saveNamesDialog: TextView = view.findViewById(R.id.saveNamesDialog)
        val cancelNamesDialog: TextView = view.findViewById(R.id.cancelNamesDialog)
        val namesSearchField: EditText = view.findViewById(R.id.namesSearchField)
        val addSearchFieldNameButton: Button = view.findViewById(R.id.addSearchFieldNameButton)
        val addSelectedNameButton: Button = view.findViewById(R.id.addSelectedNameButton)
        val removeLastButon: Button = view.findViewById(R.id.removeLastButon)

        selectedNames.setText(previousNames)

        if (selectOnlyOne){
            addSearchFieldNameButton.text = getString(R.string.select)
            addSelectedNameButton.text = getString(R.string.select)
            removeLastButon.text = getString(R.string.clear)
        }

        //set color of top part
        val namesDialogTopHalf: ConstraintLayout = view.findViewById(R.id.namesDialogTopHalf)
        (namesDialogTopHalf.background as GradientDrawable).colorFilter = PorterDuffColorFilter(activity!!.getColorFromAttr(android.R.attr.colorPrimary), PorterDuff.Mode.SRC_IN)


        val namesPickerAdapter = NamesPickeradapter(namesWorker!!) { name -> selectedName = name }  // yes this will crash if no namesworker inserted
        namesPickerList.layoutManager = LinearLayoutManager(context)
        namesPickerList.adapter = namesPickerAdapter


        //Search field changed:
        namesSearchField.onTextChanged {
            namesPickerAdapter.getNames(namesSearchField.text.toString())
        }

        //Buttons OnClickListeners:
        removeLastButon.setOnClickListener {
            if ("," in selectedNames.text.toString()){
                selectedNames.setText(selectedNames.text.toString().split(", ").dropLast(1).joinToString())
            }
            else selectedNames.setText("")
        }

        addSearchFieldNameButton.setOnClickListener {
            selectedNames.setText(if (selectOnlyOne) namesSearchField.text.toString() else listOf(selectedNames.text.toString(), namesSearchField.text.toString()).filter{x -> x.isNotEmpty()}.joinToString())
        }

        addSelectedNameButton.setOnClickListener {
            selectedNames.setText(if (selectOnlyOne) selectedName else listOf(selectedNames.text.toString(), selectedName).filter{x -> x.isNotEmpty()}.joinToString())
        }

        // Save/Cancel onClickListeners:
        saveNamesDialog.setOnClickListener{
            onSelectListener?.namesSelected(selectedNames.text.toString())
            fragmentManager?.popBackStack()
        }

        cancelNamesDialog.setOnClickListener { fragmentManager?.popBackStack() }

        return view
    }
}