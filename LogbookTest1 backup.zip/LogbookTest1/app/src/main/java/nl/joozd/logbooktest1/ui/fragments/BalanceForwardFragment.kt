package nl.joozd.logbooktest1.ui.fragments

import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ExpandableListView
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.BalanceForward
import nl.joozd.logbooktest1.data.miscClasses.TotalsListGroup
import nl.joozd.logbooktest1.ui.adapters.BalanceForwardAdapter
import nl.joozd.logbooktest1.ui.dialogs.AddBalanceForwardDialog

class BalanceForwardFragment: Fragment() {
    class OnStartListener(private val f: () -> Unit){
        fun starting(){
            f()
        }
    }
    class OnStopListener(private val f: () -> Unit){
        fun stopping(){
            f()
        }
    }

    private var adapter: BalanceForwardAdapter? = null
    private lateinit var thisView: View
    var balanceForwardData: List<TotalsListGroup> = emptyList()
    var onStart: OnStartListener? = null
    var onStop: OnStopListener? = null
    var balancesForward: List<BalanceForward> = emptyList()

    // trigger listeners onStart and onStop, in case something needs to be done (spoiler: something needs to be done)
    override fun onStart() {
        onStart?.starting()
        super.onStart()
    }

    override fun onStop() {
        onStop?.stopping()
        super.onStop()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        thisView = inflater.inflate(R.layout.balance_forward, container, false)

        val expandableList: ExpandableListView = thisView.findViewById(R.id.expandible_listview)
        adapter = BalanceForwardAdapter(requireActivity(), balanceForwardData)
        expandableList.setAdapter(adapter)

        val addBalanceButton: FloatingActionButton = thisView.findViewById(R.id.addBalanceButton)

        addBalanceButton.setOnClickListener {
            val addBalanceForwardDialog = AddBalanceForwardDialog()
            fragmentManager?.beginTransaction()
                ?.add(R.id.mainBelowMenubar, addBalanceForwardDialog)
                ?.addToBackStack(null)
                ?.commit()
        }

        return thisView
    }
}