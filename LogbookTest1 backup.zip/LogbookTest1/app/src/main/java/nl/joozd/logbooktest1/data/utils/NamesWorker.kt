package nl.joozd.logbooktest1.data.utils

import android.util.Log
import nl.joozd.logbooktest1.data.Flight

class NamesWorker (){
    class InitializationListener(private val f:() -> Unit ) {
        fun initialized(){
            f()
        }
    }
    var flightList: List<Flight> = emptyList()
    var initializationListener: InitializationListener? = null
    var nameList: List<String> = emptyList()
    var isInitialized = false
    fun initialize(newFlights: List<Flight>){
        flightList=newFlights
        Log.d ("NamesWorker", "Got ${nameList.size} names!")
        Log.d("populateNames", "got ${flightList.size} flights")
        var names: List<String> = listOf("SELF")
        flightList.forEach {
            names += unpackNames(it.name, it.name2) ?: emptyList()
        }
        nameList = names.distinct()
        Log.d("populateNames", "got ${nameList.size} names")
        isInitialized = true
        initializationListener?.initialized()
    }

    fun queryName(query: String): List<String> = nameList.filter {it.contains(query, ignoreCase = true)}
    fun getOneName (query: String): String? = nameList.firstOrNull {it.toUpperCase().contains(query.toUpperCase())}

    private fun unpackNames(vararg nameStrings: String): List<String>? {
        var names: List<String> = emptyList()
        for (nameString in nameStrings) {
            if (',' in nameString) {
                var text = nameString
                while (',' in text) {
                    val name = text.slice(0 until text.indexOf(','))
                    text = nameString.slice(text.indexOf(',') until text.length).trim(',', ' ')
                    if (name.isNotEmpty() && name != "SELF") names += name
                }
                if (text.isNotEmpty()) names += text
            } else if (nameString.isNotEmpty() && nameString != "SELF") names += nameString
        }
        return if (names.isEmpty()) null else names
    }

    fun addFlight(flight: Flight){
        nameList += unpackNames(flight.name, flight.name2)?.filter{it !in nameList} ?: emptyList()
    }
}