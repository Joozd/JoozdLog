package nl.joozd.logbooktest1.utils

import android.util.Log
import nl.joozd.logbooktest1.data.Airport
import nl.joozd.logbooktest1.extensions.toRadians
import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.log
import kotlin.math.pow


class TwilightCalculator(calculateDate: LocalDateTime) { // will know ALL the daylight an night data on calculateDate!
    private val day = Duration.between(solstice2000, calculateDate).toDays()
    private val date= calculateDate.toLocalDate()


    companion object{
        private val solstice2000 = LocalDateTime.of(2000, 12, 21, 12, 37) // future solsices are always n*365,25 days later
        private const val j = Math.PI / 182.625
        private const val axis = 23.439*Math.PI/180
        private const val twilightAngle = 6.0*Math.PI/180
    }
    fun dayTime(lat: Double, lon: Double): ClosedRange<LocalDateTime> {
        val n = 1-Math.tan(lat.toRadians())*Math.tan(
            axis *Math.cos(
                j *day))+ twilightAngle /Math.cos(lat.toRadians())
        val lengthOfDay = Math.acos(1-n)/Math.PI
        Log.d("lengthOfDay:", (lengthOfDay*24).toString())
        val utcOffset= ((lon/15)*60).toLong()
        val sunriseInZ = LocalDateTime.of(date,LocalTime.of(12,0)).minusMinutes((lengthOfDay*12*60).toLong()+utcOffset)
        val uncorrectedSunset = LocalDateTime.of(date,LocalTime.of(12,0)).plusMinutes((lengthOfDay*12*60).toLong()-utcOffset)
        val sunsetInZ = if (uncorrectedSunset < sunriseInZ) uncorrectedSunset.plusDays(1) else uncorrectedSunset
        Log.d("sunrise:", "${sunriseInZ.toDateString()}, ${sunriseInZ.toTimeString()}")
        Log.d("sunset:", "${sunsetInZ.toDateString()}, ${sunsetInZ.toTimeString()}")
        return (sunriseInZ..sunsetInZ)
    }
    fun itIsDayAt(airport: Airport, time: LocalTime): Boolean{
        return (dayTime(airport.latitude_deg, airport.longitude_deg).contains(LocalDateTime.of(date,time)))
    }
    fun itIsDayAt(lat: Double, lon: Double, time: LocalTime): Boolean{
        return (dayTime(lat, lon).contains(LocalDateTime.of(date,time)))
    }
    fun minutesOfNight(orig: Airport?, dest: Airport?, departureTime: LocalTime, arrivalTime: LocalTime): Int {
        if (orig == null || dest == null) return 0

        val duration = if (Duration.between(departureTime, arrivalTime).toMinutes() >0 ) Duration.between(departureTime, arrivalTime).toMinutes() else Duration.between(departureTime, arrivalTime).plusDays(1).toMinutes()
        val latIncrement = (dest.latitude_deg - orig.latitude_deg) / duration
        val longIncrement = (dest.longitude_deg - orig.longitude_deg) / duration
        var day = 0
        var night = 0
        for (minute: Long in (0 until duration)){
            if (itIsDayAt(orig.latitude_deg+latIncrement*minute, orig.longitude_deg+longIncrement*minute, departureTime.plusMinutes(minute))) day++ else night++
        }
        return night

/*
        if (dayDeparture){
            var lastTimeWasDay=true
            var lastTime= 0
            do{
                Log.d("Nighttime","lastTime: $lastTime")
                if (lastTimeWasDay){
                    if (duration-lastTime <= stepSize) stepSize = 2.0.pow(ceil(log((duration-lastTime).toDouble(), 2.0))).toInt() / 2
                        lastTime += stepSize
                    lastTimeWasDay = itIsDayAt(orig.latitude_deg+latIncrement*(lastTime+stepSize), orig.longitude_deg+longIncrement*(lastTime+stepSize), departureTime.plusMinutes((lastTime+stepSize).toLong()))
                    }
                else{
                    lastTime -= stepSize
                    lastTimeWasDay = itIsDayAt(orig.latitude_deg-latIncrement*(lastTime-stepSize), orig.longitude_deg-longIncrement*(lastTime-stepSize), departureTime.plusMinutes((lastTime-stepSize).toLong()))
                }

                stepSize /= 2
            } while (stepSize > 1)
            if (lastTimeWasDay)  return lastTime-1 else return return lastTime
        }

        //only option left is night departure day arrival
        Log.d("nightTime option", "4")
        var lastTimeWasDay=false
        var lastTime= 0
        do{
            if (lastTimeWasDay){
                lastTime -= stepSize
                lastTimeWasDay = itIsDayAt(orig.latitude_deg-latIncrement*(lastTime-stepSize), orig.longitude_deg-longIncrement*(lastTime-stepSize), departureTime.plusMinutes((lastTime-stepSize).toLong()))
            }
            else{
                if (duration-lastTime <= stepSize) stepSize = 2.0.pow(ceil(log((duration-lastTime).toDouble(), 2.0))).toInt() / 2
                lastTime += stepSize
                lastTimeWasDay = itIsDayAt(orig.latitude_deg+latIncrement*(lastTime+stepSize), orig.longitude_deg+longIncrement*(lastTime+stepSize), departureTime.plusMinutes((lastTime+stepSize).toLong()))
            }

            stepSize /= 2
        } while (stepSize > 1)
        if (lastTimeWasDay)  return duration-lastTime-1 else return return duration-lastTime

        */
    }

}