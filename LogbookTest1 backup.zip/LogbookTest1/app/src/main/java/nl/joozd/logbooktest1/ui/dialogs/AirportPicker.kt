package nl.joozd.logbooktest1.ui.dialogs

import android.content.Context
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import nl.joozd.logbooktest1.R
import nl.joozd.logbooktest1.data.Airport
import nl.joozd.logbooktest1.data.db.AirportDb
import nl.joozd.logbooktest1.extensions.getColorFromAttr

class AirportPicker: Fragment() {
    class AirportSelectedListener(private val f: (airport: Airport) -> Unit){
        fun airportSelected(airport: Airport){
            f(airport)
        }
    }

    private val airportDB = AirportDb()
    private var allAirports: List<Airport> = emptyList()

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        allAirports = airportDB.requestAllAirports()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.picker_airport, container,false)

        val airportPickerTopHalf: ConstraintLayout = view.findViewById(R.id.airportPickerTopHalf)


        (airportPickerTopHalf.background as GradientDrawable).colorFilter = PorterDuffColorFilter(activity!!.getColorFromAttr(android.R.attr.colorPrimary), PorterDuff.Mode.SRC_IN)


        return view
    }
}