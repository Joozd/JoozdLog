package nl.joozd.logbooktest1.utils.listeners

import android.util.Log
import android.view.View
import nl.joozd.logbooktest1.data.Flight
import nl.joozd.logbooktest1.data.db.FlightDb
import nl.joozd.logbooktest1.ui.adapters.FlightsAdapter
import nl.joozd.logbooktest1.utils.FlightSearcher

class UndoSaveFlightListener(private val oldFlight: Flight, private val flightDb: FlightDb, private val adapter: FlightsAdapter, private val meh: View?, private val flightSearcher: FlightSearcher) : View.OnClickListener {
    override fun onClick(v: View) {
        Log.d("UndoSaveFlightListener","clicked!")
        flightDb.saveFlight(oldFlight)
        adapter.insertFlight(oldFlight)
        flightSearcher.undoAdd()
        // Code to undo the user's last action
    }
}